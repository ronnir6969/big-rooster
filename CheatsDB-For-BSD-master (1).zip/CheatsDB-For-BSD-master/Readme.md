Cheats Database For Bruteforce Save Data
========================================

## ps3hax.net + aldostools.org

## Compiled by gingerbread

Please use the following channels to report cheats(new/issues/updates).
-----------------------------------------------------------------------
- Post a reply at [http://www.ps3hax.net/showthread.php?t=52344]
- Create a [__New Issue__](https://github.com/gingerbread-ps3hax/CheatsDB-For-BSD/issues). Make sure that __GameID__ and __Game Name__ is stated in the __Title Field__.
- Note : __Please do not post comments in the commit sections.__


How to use this database - Method 1
-----------------------------------

Step 1 - Download Aldo's latest Bruteforce Save Data.

Step 2 - If the installer is not using the latest database, you can download patch files individually via BSD.

Step 3 - After decrypting the Save Data, click __Cheats__. Press the __Download__ button.

![Image Alt](http://oi52.tinypic.com/2ewczsy.jpg)

Step 4 - The latest patch file will be downloaded from this repo to __C:\Program Files\Bruteforce Save Data\Cheats__

Enjoy.

How to use this database - Method 2
-----------------------------------

Step 1 - Download - [https://github.com/gingerbread-ps3hax/CheatsDB-For-BSD/archive/master.zip]

Step 2 - Extract files and Copy/Overwrite all files to __C:\Program Files\Bruteforce Save Data\Cheats__

Step 3 - Start Bruteforce Save Data

Step 4 - Refresh

Enjoy.